import java.util.Scanner;

public class BankingApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bank bank = new Bank(); // Creates a bank instance to manage accounts

        while (true) {
            // Display menu options
            System.out.println("\n===== Simple Banking System =====");
            System.out.println("1. Create Account");
            System.out.println("2. View Balance");
            System.out.println("3. Deposit Money");
            System.out.println("4. Withdraw Money");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt(); // Read user choice

            switch (choice) {
                case 1:
                    // Creating a new account
                    System.out.print("Enter Account Holder Name: ");
                    scanner.nextLine(); // Consume newline character
                    String name = scanner.nextLine();
                    System.out.print("Enter Initial Deposit Amount: ");
                    double initialDeposit = scanner.nextDouble();
                    bank.createAccount(name, initialDeposit);
                    break;
                case 2:
                    // Viewing balance
                    System.out.print("Enter Account Number: ");
                    int accNumber = scanner.nextInt();
                    bank.viewBalance(accNumber);
                    break;
                case 3:
                    // Depositing money
                    System.out.print("Enter Account Number: ");
                    int depAcc = scanner.nextInt();
                    System.out.print("Enter Amount to Deposit: ");
                    double depAmount = scanner.nextDouble();
                    bank.deposit(depAcc, depAmount);
                    break;
                case 4:
                    // Withdrawing money
                    System.out.print("Enter Account Number: ");
                    int withAcc = scanner.nextInt();
                    System.out.print("Enter Amount to Withdraw: ");
                    double withAmount = scanner.nextDouble();
                    bank.withdraw(withAcc, withAmount);
                    break;
                case 5:
                    // Exit the program
                    System.out.println("Exiting... Thank you for using our banking system.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
