import java.io.Serializable; // Allows objects to be saved to a file

public class Account implements Serializable { // Enables file storage (optional)
    private static int accountCounter = 1000; // Unique account number generator
    private int accountNumber; // Stores account number
    private String accountHolderName; // Stores account holder name
    private double balance; // Stores current account balance

    // Constructor: Creates a new account with a unique number and initial deposit
    public Account(String accountHolderName, double initialDeposit) {
        this.accountNumber = accountCounter++; // Assigns a unique account number
        this.accountHolderName = accountHolderName;
        this.balance = initialDeposit;
    }

    // Getters for account details
    public int getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    // Deposit method: Adds money to the account if the amount is positive
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit successful. New balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Withdraw method: Deducts money if the amount is valid and sufficient balance is available
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: " + balance);
            return true;
        } else {
            System.out.println("Invalid withdrawal amount or insufficient funds.");
            return false;
        }
    }
}
 