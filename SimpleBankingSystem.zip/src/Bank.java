import java.util.ArrayList;

public class Bank {
    private ArrayList<Account> accounts; // Stores multiple accounts

    // Constructor: Initializes the accounts list
    public Bank() {
        this.accounts = new ArrayList<>();
    }

    // Create a new account with the given name and initial deposit
    public Account createAccount(String name, double initialDeposit) {
        Account newAccount = new Account(name, initialDeposit);
        accounts.add(newAccount); // Adds account to the list
        System.out.println("Account created successfully. Account Number: " + newAccount.getAccountNumber());
        return newAccount;
    }

    // Find an account by account number
    public Account getAccount(int accountNumber) {
        for (Account acc : accounts) {
            if (acc.getAccountNumber() == accountNumber) {
                return acc;
            }
        }
        return null; // Returns null if account is not found
    }

    // Deposit money into an account
    public void deposit(int accountNumber, double amount) {
        Account acc = getAccount(accountNumber);
        if (acc != null) {
            acc.deposit(amount);
        } else {
            System.out.println("Account not found.");
        }
    }

    // Withdraw money from an account
    public void withdraw(int accountNumber, double amount) {
        Account acc = getAccount(accountNumber);
        if (acc != null) {
            acc.withdraw(amount);
        } else {
            System.out.println("Account not found.");
        }
    }

    // View the balance of an account
    public void viewBalance(int accountNumber) {
        Account acc = getAccount(accountNumber);
        if (acc != null) {
            System.out.println("Account Balance: " + acc.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }
}
