# Simple Banking System

## 📌 Project Overview
This is a **console-based banking system** where users can:
- Create a bank account.
- Deposit and withdraw money.
- Check account balance.

## 🛠️ Technologies Used
- **Java** (Version 8 or later)
- **IntelliJ IDEA** (Recommended IDE)

## 🚀 How to Run
1. Open **IntelliJ IDEA** and load the project.
2. Run `BankingApp.java` to start the application.
3. Use the menu options to interact with the system.

## 🔥 Features
✅ Create an Account  
✅ Deposit Money  
✅ Withdraw Money  
✅ View Balance  
✅ Error Handling

## 🤝 Contributions
Feel free to **fork** this project and improve it!

## 📝 License
This project is open-source under the **MIT License**.
